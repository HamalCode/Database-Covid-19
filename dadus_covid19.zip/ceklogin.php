<?php 
    include("config/db.php");
	$user= $_REQUEST["txtUsername"];
	$pass= $_REQUEST["txtPassword"];

	$Qu = $con->prepare("SELECT * FROM t_user WHERE BINARY(username) = :vuser && password= :pass");
	$Qu->execute(array('vuser'=>$user, 'pass'=>MD5($pass)));
	$Du=$Qu->fetch(PDO::FETCH_BOTH);
	if($Qu->rowCount()>0){
		session_start();
		$_SESSION["naranuser"]     =$Du["username"];
		$_SESSION["userpassword"]   =md5($Du["password"]);
		echo 1;

	}else{
		echo "Username no Password la Registu iha database.!";
	}
 ?>