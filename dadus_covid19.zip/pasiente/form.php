<?php
	include("../config/db.php");
	if(isset($_POST["sobre"]) && $_POST["sobre"]=="foun"){
		$no 	= "";
		$nrn 	= "";
		$ftin 	= "";
		$data	= "";
		$tinan 	= "";
		$bairo	= "";
		$alde 	= "";
		$suco	= "";
		$posto 	= "";
		$foto	= "";
		$sobre 	= "foun";
		$rd 	= "";
	}else{
		$Qedit = $con->prepare("SELECT * FROM tbl_pasiente WHERE no_registu= :nor");
		$Qedit->execute(array('nor'=>$_POST["sobre"]));
		$De = $Qedit->fetch(PDO::FETCH_LAZY);
		$no 	= $De->no_registu;
		$nrn 	= $De->naran_kompletu;
		$ftin 	= $De->fatin_moris;
		$data 	= $De->data_moris;
		$tinan 	= $De->tinan;
		$bairo 	= $De->bairo;
		$alde 	= $De->suco;
		$suco 	= $De->naran_kompletu;
		$posto 	= $De->posto;
		$foto 	= $De->foto;
		$sobre = $De->no_registu;
		$rd    = "readonly";
	}
?>
<input type="hidden" name="sobre" value="<?=$sobre;?>">
<div class="row">
	<div class="col-md-8">
		<div class="form-group row">
			<label class="col-form-label col-sm-3">No.Reg</label>
			<div class="col-sm-9">
				<input type="type" <?=$rd;?> name="txtNo" id="txtNo" class="form-control" value="<?=$no;?>">
			</div>
		</div>
		<div class="form-group row">
			<label class="col-form-label col-sm-3">Naran</label>
			<div class="col-sm-9">
				<input type="type" name="txtNrn" id="txtNrn" class="form-control" value="<?=$nrn;?>">
			</div>
		</div>
		<div class="form-group row">
			<label class="col-form-label col-sm-3">Moris Fatin</label>
			<div class="col-sm-9">
				<input type="type" name="txtFtin" id="txtFtin" class="form-control" value="<?=$ftin;?>">
			</div>
		</div>
		<div class="form-group row">
			<label class="col-form-label col-sm-3">Data Moris</label>
			<div class="col-sm-9">
				<input type="date" name="txtData" id="txtData" class="form-control" value="<?=$data;?>">
			</div>
		</div>
		<div class="form-group row">
			<label class="col-form-label col-sm-3">Tinan</label>
			<div class="col-sm-9">
				<input type="type" name="txtTinan" id="txtTinan" class="form-control" value="<?=$tinan;?>">
			</div>
		</div>
		<div class="form-group row">
			<label class="col-form-label col-sm-3">Bairo</label>
			<div class="col-sm-9">
				<input type="type" name="txtBairo" id="txtBairo" class="form-control" value="<?=$bairo;?>">
			</div>
		</div>
		<div class="form-group row">
			<label class="col-form-label col-sm-3">Aldeia</label>
			<div class="col-sm-9">
				<input type="type" name="txtAlde" id="txtAlde" class="form-control" value="<?=$alde;?>">
			</div>
		</div>
		<div class="form-group row">
			<label class="col-form-label col-sm-3">Suco</label>
			<div class="col-sm-9">
				<input type="type" name="txtSuco" id="txtSuco" class="form-control" value="<?=$suco;?>">
			</div>
		</div>
		<div class="form-group row">
			<label class="col-form-label col-sm-3">Posto</label>
			<div class="col-sm-9">
				<input type="type" name="txtPosto" id="txtPosto" class="form-control" value="<?=$posto;?>">
			</div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="form-group">
			<input type="file" name="txtFoto" onchange="$('#vfoto').attr('src', window.URL.createObjectURL(this.files[0]))">
		</div>
		<div class="form-group">
			<img id="vfoto" src="imagen/<?=$foto;?>" class="img-fluid img-thumbnail shadow">
		</div>
	</div>
</div>	