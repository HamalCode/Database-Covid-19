
<table class="table table-striped table-hover">
	<thead class="thead-light">
		<tr>
			<th>No</th>	<th>No.Reg</th> <th> Naran</th>
			<th>Moris Fatin</th>
			<th>Data Moris</th>
			<th>Tinan</th>
			<th>Bairo</th>
			<th>Aldeia</th>
			<th>Suco</th>
			<th>Posto</th>
			<th>Foto</th>
			<th>Asaun</th>
		</tr>
	</thead>
	<tbody>
		<?php
		$no=1;
		include("../config/db.php");
		$Qkt=$con->query("SELECT * FROM tbl_pasiente");
		while($Dpt=$Qkt->fetch(PDO::FETCH_LAZY)) {
			echo "
			<tr>
				<td>$no</td> 
				<td>$Dpt->no_registu</td>
				<td>$Dpt->naran_kompletu</td>
				<td>$Dpt->fatin_moris</td>
				<td>$Dpt->data_moris</td>
				<td>$Dpt->tinan</td>
				<td>$Dpt->bairo</td>
				<td>$Dpt->aldeia</td>
				<td>$Dpt->suco</td>
				<td>$Dpt->posto</td>
				<td><img src='imagen/$Dpt->foto' width='110' class='img-fluid img-thumbnail'></td>
				<td width='160'>
					<button id='$Dpt->no_registu' class='renova btn btn-warning btn-sm' data-target='#mmodal' data-toggle='modal' data-backdrop='static'>Renova</button>

					<button id='$Dpt->no_registu' class='apaga btn btn-danger btn-sm'>apaga</button>
				</td>
			</tr>
			";
			$no++;
		}
		?>
	</tbody>
</table>