<?php
	include '../config/db.php';
	if(isset($_POST["sobre"])){
		$no		= $_POST["txtNo"];
		$nrn 	= $_POST["txtNrn"];
		$ftin 	= $_POST["txtFtin"];
		$data   = $_POST["txtData"];
		$tinan 	= $_POST["txtTinan"];
		$bairo 	= $_POST["txtBairo"];
		$alde	= $_POST["txtAlde"];
		$suco 	= $_POST["txtSuco"];
		$posto 	= $_POST["txtPosto"];

		if($_POST["sobre"]=="foun"){
			$Qin = $con->prepare("INSERT INTO tbl_pasiente 
				SET no_registu=:no, naran_kompletu=:nrn, fatin_moris=:ftin, data_moris=:data, tinan=:tinan, bairo=:bairo, aldeia=:alde, suco=:suco, posto=:posto");



			$Qin->execute(array('no'=>$no, 'nrn'=>$nrn, 'ftin'=>$ftin, 'data'=>$data, 'tinan'=>$tinan, 'bairo'=>$bairo, 'alde'=>$alde, 'suco'=>$suco, 'posto'=>$posto));

		}else if($_POST["sobre"]=="apagadadus"){
			$Qdl = $con->prepare("DELETE FROM tbl_pasiente WHERE no_registu= :no");
			$Qdl->execute(array('no'=>$_POST["idapaga"]));
		}else{
			$Qup = $con->prepare("UPDATE tbl_pasiente 
				SET naran_kompletu = :nrn, fatin_moris = :ftin, data_moris= :data, tinan= :tinan, bairo= :bairo, aldeia= :alde, suco= :suco, posto= :posto
				WHERE no_registu= :no");
			$Qup->execute(array('no'=>$no, 'nrn'=>$nrn, 'ftin'=>$ftin, 'data'=>$data, 'tinan'=>$tinan, 'bairo'=>$bairo, 'alde'=>$alde, 'suco'=>$suco, 'posto'=>$posto));
		}

		if(!empty($_FILES["txtFoto"]["tmp_name"])){
			$fatin_up  = $_FILES["txtFoto"]["tmp_name"];
			$nrn_file  = $_FILES["txtFoto"]["name"];
			$ext 			 = pathinfo($nrn_file, PATHINFO_EXTENSION);
			$fatin_rai = "../imagen/$no.$ext";
			move_uploaded_file($fatin_up, $fatin_rai); 

			$Qup=$con->prepare("UPDATE tbl_pasiente SET foto= :img WHERE no_registu = :nor");
			$Qup->execute(array('img'=>"$no.$ext", 'nor'=>$no));
		}
	}
?>
