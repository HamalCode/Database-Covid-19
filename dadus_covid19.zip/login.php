<!DOCTYPE html>
<html>
<head>
	<title>Login Administrator</title>
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="Jquery/sweetalert/wordpress-admin/wordpress-admin.css">
</head>
<body>
	<div class="container text-center">
		<p class="display-4">ADMINISTRATOR SYSTEM</p>
		<div class="row justify-content-center">
			<div class="col-md-6">

		<div class="card">
			<form id="formlogin">
				<div class="card-header bg-danger">
					<h1 class="card-title"><font face="Karumbi">  </i>Login Administrator</font> </h1>
				</div>

				<div class="card-body">
					<div class="form-group row">
						<label class="col-form-label col-sm-3"> Username <i class="fa fa-user"></i></label>
						<div class="col-sm-9">
							<input type="text" name="txtUsername" id="txtUsrname" class="form-control" required>

						</div>
					</div>

					<div class="form-group row">
						<label class="col-form-label col-sm-3">Password <i class="fa fa-lock"></i></label>
						<div class="col-sm-9">
							<input type="password"  name="txtPassword" id="txtPassword" class="form-control" required>
						
						</div>
					</div>

					<div class="card-footer bg-dark">
					<button class="btn btn-light btn-sm" type="reset">Cancel</button>
					<button class="btn btn-success btn-sm" type="submit">Login</button>
				</div>
				</div>

				
			 </form>
			</div>
		  </div>
		</div>	
	</div>
</div>
</body>

</body>
<script type="text/javascript" src="Jquery/jquery-3.5.1.js"></script>
<script type="text/javascript" src="Bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="Jquery/sweetalert/sweetalert2.min.js"></script>
<script type="text/javascript">
	$(function(){
    $("#formlogin").submit(function(e){
      e.preventDefault();
      var dadus  = new FormData(this);
      var ceklog = "ceklogin.php";
      // uza ajax
      $.ajax({
          type        :   "POST",
          url         :   ceklog,
          data        :   dadus,
          cashe       :   false,
          contentType : false,
          processData : false,
          mimeType    : "multipart/form-data",
          success     : function(rezlogin){
          	if(rezlogin != 1){
       Swal.fire({position : 'center-middle', icon : 'error', title : rezlogin, showConfirmButton : false, timer: 1500});
	}else{
		location.assign("index.php");
	    }
      }
      });
    });
  });

</script>
</html>
