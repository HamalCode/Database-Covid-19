<?php 
	$server 	= "localhost";
	$user 		= "root";
	$pass 		= "";
	$port 		= "3306";
	$db 		= "covid19";

	try{
		$con = new PDO('mysql:server='.$server.'; dbname='.$db.';
			port='.$port.';',$user, $pass);
		$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}catch(PDOException $e){
		echo "Koneksaun ba Base de Dadus Error : ". $e->getMessage();
		exit();
	}
?>
