<!DOCTYPE html>
<html>
<head>
	<title>Dadus Covid-19</title>
	<link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.css">
	
</head>
<body>
	<div class="alert alert-light" role="alert">

 <p align="center"><img src="imagen/ms.jpeg" width="10%">    
 	<b style="color: green;">DADUS PASIENTE NEBE POZITIVU COVID-19 IHA TIMOR LESTE</b>
 	<img src="imagen/oms.jpeg" width="15%"> </p><br>
 	<p align="center" style="color: blue;"> <i>Rua: Ministerio da saude, palacio das Cinzas caicoli DIli, Timor-leste.</i> <br>
 	<i> Contacto Centro emergencia </i>: <i class="fa fa-3x fa-phone">199</i></p>
 	 <hr>
</div>
	<div class="container border mt-3 p-2">
		<button class="btn btn-warning aumenta" data-target="#mmodal" 
		data-toggle="modal" data-backdrop="static"><i class="fa fa-plus"></i>Aumenta Dadus</button>
		<p align="right"><button type="button" class="btn btn-danger"> <a href="login.php">Log Out</a></button></p>
		<!--Fatin Dadus-->
		<div class="col-md-12 border mt-2 fatin-dadus">
		</div>
<!--Form Dadus-->
	<div class="modal fade" id="mmodal">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
		<form id="mform">
				<div class="modal-header bg-warning">
					<h4 class="modal-title text-white"> Form Input Dadus Pasien Covid</h4>
					<button class="close" data-dismiss="modal">&times</button>
				</div>
				<div class="modal-body fatin-form">
				</div>
				<div class="modal-footer justify-content-between bg-light">
					<button type="reset" class="btn btn-danger btn-sm" data-dismiss="modal"><i class="fa fa-close"></i> Tama</button>
					<button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-save"></i> Rai Dadus</button>
				</div>
			</form>
			</div> 
		</div>
	</div><!--Termina Form-->
	</div>
</body>
<script type="text/javascript" src="Jquery/jquery-3.5.1.js"></script>
<script type="text/javascript" src="Bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="Jquery/sweetalert.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		function loadadus(){
			var urld = "pasiente/dadus.php";
			$.post(urld,{sobre : 'foti-dadus'}, function(dadus){
				$(".fatin-dadus").html(dadus);	
			});
		}
		loadadus();

		$(".aumenta").click(function(){
			var urlf = "pasiente/form.php";
			$.post(urlf, {sobre : 'foun'}, function(dform){
				$(".fatin-form").html(dform);
			});
		});

		/* Butaun Renova Dadus nian */
		$("body").delegate(".renova","click", function(){
			var fid = this.id;
			var urlf = "pasiente/form.php";
			$.post(urlf, {sobre : fid}, function(dform){
				$(".fatin-form").html(dform);
			});
		});

		/* Butaun Renova Dadus nian */
		$("body").delegate(".apaga","click", function(){
			var fid = this.id;
			Swal.fire({
				title : "Apaga Dadus",
				text : "Hakarak Apaga dadus Ne'e??",
				icon : "question",
				showCancelButton : true,
				cancelButtonColor : '#850000',
				cancelButtonText : 'Cancela Apaga'
			}).then((konfrma)=>{
				if(konfrma.isConfirmed){

			var urlf = "pasiente/exc.php";
			$.post(urlf, {sobre : 'apagadadus', idapaga : fid}, function(dform){
					loadadus();
			});

				}
			})
		});

		$("#mform").submit(function(frm){
			frm.preventDefault();
			var urlm  = "pasiente/exc.php";
			var dadus = new FormData(this);
			$.ajax({
				type 				: "POST",
				url 				: urlm,
				data 				: dadus,
				mimeType 		: "multipart/form-data",
				cashe 			: false,
				contentType : false,
				processData	: false,
				success			: function(rez){
					alert(rez);
					loadadus();
				}
			});
		});
	});
</script>
</html>