<?php 
	if(!isset($_SESSION)){
		session_start();
	}
	
	if(!empty($_SESSION["naranuser"]) && !empty($_SESSION["userpassword"])){
		header('location:content.php');
	}else{
		header('localion:login.php');
	}
 ?>